---
name: Proposal
about: Propose a new feature or change to a feature for Hugo-PaperMod.
title: ""
labels: "enhancement"
assignees: ""
---
